#include<stdio.h>
#include<cs50.h>

int main(void)
{
  int n,i,j,k,count=1;
     do
    {
        if(count<=3)
        {
          printf("Height:");
          n=get_int();
          count++;
        }
      
        else
         { 
          printf("Retry:");
          n=get_int();
         }
    }
    while(n<0||n>23) ;
    
    for(i=0;i<n;i++)
       
       {
         for(k=n-i;k>1;k--)
         {
             printf(" ");
             
         }
        
            for(j=0;j<=i+1;j++)
            {
            
               printf("#");
            }
            printf("\n");
       }    
}