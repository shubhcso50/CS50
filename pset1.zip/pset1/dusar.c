#include<stdio.h>
#include<cs50.h>
#include<math.h>

int main(void)
{
 int amount,count=0,coins=0;
 float n,x;
 do
 {if(count<=0)
     printf("O hai! How much change is owed?\n");
 else if(count<=2) 
     printf("How much change is owed?\n");
 else
     printf("Retry:\t");
     n=GetFloat();
     count++;
 }while(n<=0);
   x=100*n;
   amount=round(x);
   while(amount>=25)
   {
    coins=amount/25;
    amount=amount%25;
   }
   while(amount>=10)
   {
    coins=amount/10;
    amount=amount%10;
   }
   while(amount>=5)
   {
    coins=amount/5;
    amount=amount%5;
   }
   coins=coins+amount;
   printf("%d\n",coins);
}
    