#include<stdio.h>
#include<cs50.h>

int main(void)
{
    int time,nb;
    do
    {
    printf("minutes:");
    time=GetInt();
    }while(time<0);
    nb=12*time;
    printf("bottles:%d\n",nb);
}